#!/bin/bash
echo 'Package script placeholder'